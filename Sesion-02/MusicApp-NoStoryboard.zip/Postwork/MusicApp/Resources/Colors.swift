//
//  Colors.swift
//  MusicApp
//
//  Copyright © 2019 Bedu. All rights reserved.
//

import UIKit

// Gray #191B23
let BackGroundColor =  UIColor(red:0.10, green:0.11, blue:0.14, alpha:1.00)
let TextGrayColor = UIColor(red:0.38, green:0.39, blue:0.41, alpha:1.00)



