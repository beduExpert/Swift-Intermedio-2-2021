//
//  ScrollViewController.swift
//  MusicApp
//
//  Created by Omar Guzmán on 11/10/21.
//  Copyright © 2021 Bedu. All rights reserved.
//

import UIKit

class ScrollViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
