# Cities_Share
A simple tutorial for UICollectionView in swift. Github link of the tutorial on Medium.com
