//
//  City.swift
//  Cities
//
//  Created by Omar Guzmán on 12/10/21.
//

import Foundation

struct City {
    var image: String
    var name: String
}
