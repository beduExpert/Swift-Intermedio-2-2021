//
//  CityCollectionViewCell.swift
//  Cities
//
//  Created by Omar Guzmán on 12/10/21.
//

import UIKit

class CityCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var cityImageView: UIImageView!
    @IBOutlet weak var cityNameLabel: UILabel!
}
